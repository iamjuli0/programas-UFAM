#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix *matrix_create(size_t rows, size_t cols) {
    Matrix *m = (Matrix *)malloc(sizeof(Matrix));
    m->rows = rows;
    m->cols = cols;
    m->data = (double **)malloc(rows * sizeof(double *));
    for (size_t i = 0; i < rows; ++i)
        m->data[i] = (double *)malloc(cols * sizeof(double));
    return m;
}

void matrix_free(Matrix *m) {
    for (size_t i = 0; i < m->rows; ++i)
        free(m->data[i]);
    free(m->data);
    free(m);
}

Matrix *matrix_add(const Matrix *a, const Matrix *b) {
    if (a->rows != b->rows || a->cols != b->cols) return NULL;
    Matrix *result = matrix_create(a->rows, a->cols);
    for (size_t i = 0; i < a->rows; ++i)
        for (size_t j = 0; j < a->cols; ++j)
            result->data[i][j] = a->data[i][j] + b->data[i][j];
    return result;
}

Matrix *matrix_scalar_multiply(const Matrix *m, double scalar) {
    Matrix *result = matrix_create(m->rows, m->cols);
    for (size_t i = 0; i < m->rows; ++i)
        for (size_t j = 0; j < m->cols; ++j)
            result->data[i][j] = m->data[i][j] * scalar;
    return result;
}

void matrix_print(const Matrix *m) {
    for (size_t i = 0; i < m->rows; ++i) {
        for (size_t j = 0; j < m->cols; ++j)
            printf("%.2f ", m->data[i][j]);
        printf("\n");
    }
}