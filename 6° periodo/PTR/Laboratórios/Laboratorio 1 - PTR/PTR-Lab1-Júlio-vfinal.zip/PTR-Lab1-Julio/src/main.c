#include <stdio.h>
#include "dstring.h"
#include "matrix.h"
#include "integral.h"

double func(double x) {
    return x * x;
}

int main() {
    // Testando Dstring
    Dstring *hello = dstring_create("Hello");
    Dstring *world = dstring_create(" World!");
    Dstring *message = dstring_concat(hello, world);
    printf("Mensagem: %s\n", $(message));
    dstring_free(hello); dstring_free(world); dstring_free(message);

    // Testando Matrix
    Matrix *a = matrix_create(2, 2);
    Matrix *b = matrix_create(2, 2);
    a->data[0][0] = 1; a->data[0][1] = 2;
    a->data[1][0] = 3; a->data[1][1] = 4;
    b->data[0][0] = 5; b->data[0][1] = 6;
    b->data[1][0] = 7; b->data[1][1] = 8;
    Matrix *sum = matrix_add(a, b);
    printf("Soma de Matrizes:\n");
    matrix_print(sum);
    matrix_free(a); matrix_free(b); matrix_free(sum);

    // Testando Integral
    printf("Integral de x^2 de 0 a 2:\n");
    printf("Riemann: %.4f\n", riemann_sum(func, 0, 2, 10));
    printf("Trapézio: %.4f\n", trapezoidal_rule(func, 0, 2, 10));
    printf("Simpson: %.4f\n", simpson_rule(func, 0, 2, 10));

    return 0;
}