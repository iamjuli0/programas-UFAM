#include "dstring.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Dstring *dstring_create(const char *str) {
    Dstring *ds = (Dstring *)malloc(sizeof(Dstring));
    ds->length = strlen(str);
    ds->data = (char *)malloc(ds->length + 1);
    strcpy(ds->data, str);
    return ds;
}

Dstring *dstring_from_int(int value) {
    char buffer[50];
    snprintf(buffer, sizeof(buffer), "%d", value);
    return dstring_create(buffer);
}

Dstring *dstring_concat(const Dstring *a, const Dstring *b) {
    Dstring *result = (Dstring *)malloc(sizeof(Dstring));
    result->length = a->length + b->length;
    result->data = (char *)malloc(result->length + 1);
    strcpy(result->data, a->data);
    strcat(result->data, b->data);
    return result;
}

size_t dstring_length(const Dstring *ds) {
    return ds->length;
}

char *dstring_to_char(const Dstring *ds) {
    return ds->data;
}

void dstring_free(Dstring *ds) {
    free(ds->data);
    free(ds);
}