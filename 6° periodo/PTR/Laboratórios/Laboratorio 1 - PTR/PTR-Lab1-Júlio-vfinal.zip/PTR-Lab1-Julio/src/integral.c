#include "integral.h"

double riemann_sum(Func f, double a, double b, int n) {
    double dx = (b - a) / n, sum = 0.0;
    for (int i = 0; i < n; i++)
        sum += f(a + i * dx) * dx;
    return sum;
}

double trapezoidal_rule(Func f, double a, double b, int n) {
    double dx = (b - a) / n, sum = (f(a) + f(b)) / 2.0;
    for (int i = 1; i < n; i++)
        sum += f(a + i * dx);
    return sum * dx;
}

double simpson_rule(Func f, double a, double b, int n) {
    if (n % 2 != 0) n++;
    double dx = (b - a) / n, sum = f(a) + f(b);
    for (int i = 1; i < n; i++) {
        double x = a + i * dx;
        sum += f(x) * (i % 2 == 0 ? 2 : 4);
    }
    return sum * dx / 3.0;
}