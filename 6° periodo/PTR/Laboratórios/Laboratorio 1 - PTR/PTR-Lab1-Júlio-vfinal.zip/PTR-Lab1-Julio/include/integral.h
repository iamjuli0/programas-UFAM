#ifndef INTEGRAL_H
#define INTEGRAL_H

#include <stddef.h>

typedef double (*Func)(double);

double riemann_sum(Func f, double a, double b, int n);
double trapezoidal_rule(Func f, double a, double b, int n);
double simpson_rule(Func f, double a, double b, int n);

#endif