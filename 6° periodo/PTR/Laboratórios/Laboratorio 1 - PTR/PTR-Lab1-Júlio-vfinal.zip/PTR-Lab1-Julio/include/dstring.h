#ifndef DSTRING_H
#define DSTRING_H

#include <stddef.h>

typedef struct {
    char *data;
    size_t length;
} Dstring;

Dstring *dstring_create(const char *str);
Dstring *dstring_from_int(int value);
Dstring *dstring_concat(const Dstring *a, const Dstring *b);
size_t dstring_length(const Dstring *ds);
char *dstring_to_char(const Dstring *ds);
#define $ dstring_to_char
void dstring_free(Dstring *ds);

#endif