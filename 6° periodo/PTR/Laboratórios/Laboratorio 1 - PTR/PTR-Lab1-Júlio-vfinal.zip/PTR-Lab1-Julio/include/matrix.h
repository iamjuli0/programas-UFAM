#ifndef MATRIX_H
#define MATRIX_H

#include <stddef.h>

typedef struct {
    double **data;
    size_t rows, cols;
} Matrix;

Matrix *matrix_create(size_t rows, size_t cols);
void matrix_free(Matrix *m);
Matrix *matrix_add(const Matrix *a, const Matrix *b);
Matrix *matrix_scalar_multiply(const Matrix *m, double scalar);
void matrix_print(const Matrix *m);

#endif