#ifndef REFERENCIAS_H
#define REFERENCIAS_H
#define M_PI 3.14159265358979323846
#define ALPHA1 3.0
#define ALPHA2 3.0

typedef struct {
    double xmx;
    double ymy;
} Referencia;

void gerar_referencia(double tempo_atual, double *x_ref, double *y_ref);
void atualizarModeloReferenciaX(double* xmx, double xref, double dt);
void atualizarModeloReferenciaY(double* ymy, double yref, double dt);

#endif // REFERENCIAS_H
