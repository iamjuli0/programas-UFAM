#include "referencias.h"
#include <math.h>

// Função para gerar as referências x_ref e y_ref com base no tempo
void gerar_referencia(double dt, double *x_ref, double *y_ref) {
    *x_ref = (5.0 / M_PI) * cos(0.2 * M_PI * dt);
    if (dt < 10) {
        *y_ref = (5.0 / M_PI) * sin(0.2 * M_PI * dt);
    } else {
        *y_ref = -(5.0 / M_PI) * sin(0.2 * M_PI * dt);
    }
}

void calcularControle(double xmx, double ymy, double x, double y, Entrada* entrada) {
    entrada->v = ALPHA1 * (xmx - x);
    entrada->w = ALPHA2 * (ymy - y);
}

void atualizarModeloReferenciaX(double* xmx, double xref, double dt) {
    *xmx += ALPHA1 * (xref - *xmx) * dt;
}

void atualizarModeloReferenciaY(double* ymy, double yref, double dt) {
    *ymy += ALPHA2 * (yref - *ymy) * dt;
}