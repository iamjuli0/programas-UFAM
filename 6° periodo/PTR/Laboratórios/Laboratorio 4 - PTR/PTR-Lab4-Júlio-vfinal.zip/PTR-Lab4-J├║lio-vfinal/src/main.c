#include "sistema.h"
#include "io.h"
#include "utils.h"
#include "stats.h"
#include "referencias.h"

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define SIM_STEP 30  // Período de simulação em ms
#define OUTPUT_STEP 50.0 // Período de saída em ms
#define SIM_TIME 20.0 // Tempo total de simulação em segundos

Sistema sistema;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
double xref, yref;
Referencia v = {0.0, 0.0};

/*void *thread_simulacao(void *) { //uthread
    double t = 0.0;
    struct timespec tp_start, tp_stop;

    FILE *arquivo = fopen("saida.txt", "w");
    if (!arquivo) {
        perror("Erro ao abrir o arquivo");
        return NULL;
    }

    clock_gettime(CLOCK_MONOTONIC, &tp_start);
    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        atualizar_entrada(&sistema, t);
        atualizar_estado(&sistema, SIM_STEP / 1000.0); // Converte ms para s
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = OUTPUT_STEP*1000000};
        nanosleep(&req, NULL);
    }

    fclose(arquivo);
    return NULL;
}

void *thread_saida(void *) { //ythread
    double t = 0.0;
    struct timespec tp_start, tp_stop;

    FILE *arquivo = fopen("saida.txt", "a");
    if (!arquivo) {
        perror("Erro ao abrir o arquivo");
        return NULL;
    }

    clock_gettime(CLOCK_MONOTONIC, &tp_start);
    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        calcular_saida(&sistema);
        salvar_estado(arquivo, t, &sistema);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 50000000};
        nanosleep(&req, NULL);
    }

    fclose(arquivo);
    return NULL;
}*/

// Thread para cálculo do controle
void* thread_controle(void* arg) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;

    clock_gettime(CLOCK_MONOTONIC, &tp_start);
    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        calcularControle(v.xmx, v.ymy, estado.x, estado.y, &entrada);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 50000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

// Thread para linearização
void* thread_linearizacao(void* arg) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;

    clock_gettime(CLOCK_MONOTONIC, &tp_start);
    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        linearizarSistema(&estado, &entrada);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 40000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

// Thread para simulação do robô
void* thread_simulacao(void* arg) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;

    clock_gettime(CLOCK_MONOTONIC, &tp_start);
    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        calcularLinearizacao(&estado, &entrada, &estado, DT);
        printf("t=%.2f | Posição: (%.2f, %.2f) | Orientação: %.2f rad | Referência: (%.2f, %.2f)\n", 
               t, estado.x, estado.y, estado.theta, v.xmx, v.ymy);
        t += DT;
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 30000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

void* thread_referencias(void* arg) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        calcularReferencias(t, &xref, &yref);
        v.xmx = xref;
        v.ymy = yref;
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 120000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

// Thread para geração de referências
void *thread_gerar_referencia(void *args) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    double x_ref = 0.0, y_ref = 0.0;

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        gerar_referencia(t, &x_ref, &y_ref);
        pthread_mutex_unlock(&mutex);

        // Esperar 120ms
        struct timespec req = {.tv_sec = 0, .tv_nsec = 120000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

// Thread para atualização do modelo de referência - direção X
void* thread_modelo_ref_x(void* arg) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        atualizarModeloReferenciaX(&v.xmx, xref, DT);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 50000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

// Thread para atualização do modelo de referência - direção Y
void* thread_modelo_ref_y(void* arg) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        atualizarModeloReferenciaY(&v.ymy, yref, t);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 50000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

void gerar_graficos(const char *filename) {
    FILE *gnuplotPipe = popen("gnuplot -persistent", "w");
    if (gnuplotPipe == NULL) {
        fprintf(stderr, "Erro ao abrir o Gnuplot.\n");
        return;
    }

    fprintf(gnuplotPipe, "set title 'Gráfico com múltiplos eixos Y'\n"); // Título
    fprintf(gnuplotPipe, "set xlabel 'Tempo (t) [s]'\n");                // Rótulo do eixo X
    fprintf(gnuplotPipe, "set ylabel 'Valores'\n");                      // Rótulo do eixo Y
    fprintf(gnuplotPipe, "set grid\n");                                  // Grade
    fprintf(gnuplotPipe, "set key outside\n");                           // Legenda fora do gráfico

    //fprintf(gnuplotPipe, "set multiplot layout 2,1 title 'Gráficos Combinados'\n");

    fprintf(gnuplotPipe,
            "plot '%s' using 1:4 with lines title '|xc|', "
            "'%s' using 1:5 with lines title '|yc|', "
            "'%s' using 1:6 with lines title '|θ|'\n",
            filename, filename, filename);

    /*fprintf(gnuplotPipe,
            "plot '%s' using 4:5 with lines title 'Trajetória: |xc| x |yc|'\n",
            filename);*/

    //fprintf(gnuplotPipe, "unset multiplot\n");

    pclose(gnuplotPipe);

    printf("Gráfico gerado com sucesso para o arquivo '%s'.\n", filename);
}


int main() {
    pthread_t th_ref, th_modelo_ref_x, th_modelo_ref_y, th_controle, th_simulacao, th_linearizacao;
    const char *arquivo = "saida.txt";
    double *tempos = NULL, *t_values = NULL, *j_values = NULL;
    Estatisticas stats_t, stats_j;
    size_t tamanho;

    inicializar_sistema(&sistema);

    pthread_create(&th_ref, NULL, thread_referencias, NULL);
    //pthread_create(&th_modelo_ref_x, NULL, thread_modelo_ref_x, NULL);
    //pthread_create(&th_modelo_ref_y, NULL, thread_modelo_ref_y, NULL);
    pthread_create(&th_controle, NULL, thread_controle, NULL);
    pthread_create(&th_linearizacao, NULL, thread_linearizacao, NULL);
    pthread_create(&th_simulacao, NULL, thread_simulacao, NULL);

    pthread_join(th_ref, NULL);
    pthread_join(th_modelo_ref_x, NULL);
    pthread_join(th_modelo_ref_y, NULL);
    pthread_join(th_controle, NULL);
    pthread_join(th_linearizacao, NULL);
    pthread_join(th_simulacao, NULL);

    gerar_graficos(arquivo);

    tamanho = ler_dados(arquivo, &tempos, &t_values, &j_values);
    if (tamanho == 0) {
        printf("Erro ao processar os dados.\n");
        return 1;
    }

    stats_t = calcular_estatisticas(t_values, tamanho - 1);
    stats_j = calcular_estatisticas(j_values, tamanho - 1);

    imprimir_tabela(stats_t, stats_j);

    free(tempos);
    free(t_values);
    free(j_values);

    return 0;
}
