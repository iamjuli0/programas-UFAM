#ifndef IO_H
#define IO_H

#include "sistema.h"

// Funções para entrada e saída
void gerar_entrada(Sistema *sistema, double tempo_atual);
void salvar_estado(FILE *arquivo, double tempo_atual, Sistema *sistema, double x_ref, double y_ref);

#endif // IO_H
