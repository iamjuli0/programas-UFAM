#include "referencias.h"
#define ALPHA1 3.0
#define ALPHA2 3.0

// Função para calcular os erros de referência
void calcular_referencias(Sistema *sistema, double x_ref, double y_ref, double *e_x, double *e_y) {
    *e_x = x_ref - sistema->x[0];
    *e_y = y_ref - sistema->x[1];
}

void gerar_referencia(double dt, double *x_ref, double *y_ref) {
    *x_ref = (5.0 / M_PI) * cos(0.2 * M_PI * dt);
    if (dt < 10) {
        *y_ref = (5.0 / M_PI) * sin(0.2 * M_PI * dt);
    } else {
        *y_ref = -(5.0 / M_PI) * sin(0.2 * M_PI * dt);
    }
}

void atualizar_modelo_referencia(double y_mx, double y_my, double x_ref, double y_ref) {
    y_mx += ALPHA1 * (x_ref - y_mx);
    y_my += ALPHA2 * (y_ref - y_my);
}