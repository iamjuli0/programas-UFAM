#include "sistema.h"
#include <math.h>

// Inicializa o estado do sistema
void inicializar_estado(Sistema *sistema) {
    sistema->x[0] = 0.0; // xc
    sistema->x[1] = 0.0; // yc
    sistema->x[2] = 0.0; // theta
    sistema->u[0] = 0.0; // v
    sistema->u[1] = 0.0; // w
    sistema->diametro = 0.6;    // Diâmetro do robô
}

void atualizar_dinamica(Sistema *sistema, double dt) {
    double x_dot[3];
    x_dot[0] = sistema->u[0] * cos(sistema->x[2]);
    x_dot[1] = sistema->u[0] * sin(sistema->x[2]);
    x_dot[2] = sistema->u[1];

    for (int i = 0; i < 3; i++) {
        sistema->x[i] += dt * x_dot[i];
    }
}

void calcular_saida(Sistema *sistema) {
    sistema->yf[0] = sistema->x[0] + (0.5 * sistema->diametro * cos(sistema->x[2]));
    sistema->yf[1] = sistema->x[1] + (0.5 * sistema->diametro * sin(sistema->x[2]));
    sistema->yf[2] = sistema->x[2];
}
