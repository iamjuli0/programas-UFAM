#include "io.h"
#include <math.h>

void gerar_entrada(Sistema *sistema, double tempo_atual) {
    double w = 0.2 * M_PI;

    if (tempo_atual < 10) {
        sistema->u[0] = 1.0;
        sistema->u[1] = w;
    } else {
        sistema->u[0] = 1.0;
        sistema->u[1] = -w;
    }
}

void salvar_estado(FILE *arquivo, double tempo_atual, Sistema *sistema, double x_ref, double y_ref) {
    static int cabecalho = 0;

    if (!cabecalho) {
        fprintf(arquivo, "|t(s)|\t|v|\t|w|\t |xc| |yc| |θ| |xref| |yref|\n");
        fprintf(arquivo, "----------------------------------------------------------------------\n");
        cabecalho = 1;
    }

    fprintf(arquivo, "%.5f %.5f %.5f %.2f %.2f %.2f %.2f %.2f\n",
            tempo_atual, sistema->u[0], sistema->u[1],
            sistema->x[0], sistema->x[1], sistema->x[2],
            x_ref, y_ref);
}
