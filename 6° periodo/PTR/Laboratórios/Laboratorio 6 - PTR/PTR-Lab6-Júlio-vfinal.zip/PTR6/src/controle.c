#include "controle.h"

// Função para calcular o controlador baseado no modelo de referência
void calcular_controlador(Sistema *sistema, double x_ref, double y_ref) {
    double erro_x = sistema->x[0] - x_ref;
    double erro_y = sistema->x[1] - y_ref;

    // Parâmetros do controlador
    double alfa1 = 3.0;
    double alfa2 = 3.0;

    // Calculando as velocidades de controle
    sistema->u[0] = alfa1 * erro_x;  // v
    sistema->u[1] = alfa2 * erro_y;  // w
}
