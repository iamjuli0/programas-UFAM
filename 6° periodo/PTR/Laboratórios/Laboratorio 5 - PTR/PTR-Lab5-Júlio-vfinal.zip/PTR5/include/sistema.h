#ifndef SISTEMA_H
#define SISTEMA_H

#include <stdio.h>

// Estrutura do Sistema
typedef struct {
    double x[3];    // xc, yc, theta
    double u[2];   // v, w
    double diametro;      // Diâmetro do robô
    double yf[3];  // x_f, y_f, theta (do ponto frontal)
} Sistema;

// Funções do sistema
void inicializar_estado(Sistema *sistema);
void atualizar_dinamica(Sistema *sistema, double dt);
void calcular_saida(Sistema *sistema);

#endif // SISTEMA_H
