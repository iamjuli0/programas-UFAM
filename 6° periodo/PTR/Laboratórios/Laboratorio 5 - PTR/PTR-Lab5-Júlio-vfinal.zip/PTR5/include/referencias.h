#ifndef REFERENCIAS_H
#define REFERENCIAS_H

#include "sistema.h"
#include "math.h"

// Função para calcular as referências de controle
void calcular_referencias(Sistema *sistema, double x_ref, double y_ref, double *erro_x, double *erro_y);

void gerar_referencia(double tempo_atual, double *x_ref, double *y_ref);

void atualizar_modelo_referencia(double y_mx, double y_my, double pos_x, double pos_y);

#endif // REFERENCIAS_H
