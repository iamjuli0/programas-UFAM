#ifndef CONTROLE_H
#define CONTROLE_H

#include "sistema.h"

// Função para calcular o controlador baseado no modelo de referência
void calcular_controlador(Sistema *sistema, double x_ref, double y_ref);

#endif // CONTROLE_H
