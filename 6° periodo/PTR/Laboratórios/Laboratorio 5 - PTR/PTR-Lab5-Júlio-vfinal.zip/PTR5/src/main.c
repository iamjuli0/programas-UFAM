#include "sistema.h"
#include "controle.h"
#include "referencias.h"
#include "utils.h"
#include "io.h"
#include "stats.h"
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>

#define SIM_TIME 20.0 // Tempo total da simulação

// Variáveis globais
Sistema sistema;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
double y_mx = 0.0, y_my = 0.0; // Modelos de referência
double u1 = 0.0, u2 = 0.0;     // Controles desacoplados

// Função para imprimir no terminal
void imprimir_terminal(double t, Sistema *sistema, double x_ref, double y_ref) {
    printf("%.5f %.5f %.5f %.2f %.2f %.2f %.2f %.2f\n",
            t, sistema->u[0], sistema->u[1],
            sistema->x[0], sistema->x[1], sistema->x[2],
            x_ref, y_ref);
}

// Thread para simulação dinâmica
void *thread_simulacao_dinamica(void *) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        gerar_entrada(&sistema, t);
        atualizar_dinamica(&sistema, 0.03);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 30000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

// Thread para controle
void *thread_controle(void *) {
    double t = 0.0;
    double x_ref, y_ref;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    FILE *arquivo = fopen("saida.txt", "w");
    if (!arquivo) {
        perror("Erro ao abrir o arquivo");
        return NULL;
    }

    // Impressão do cabeçalho no terminal
    printf("|t(s)|\t|v|\t|w|\t |xc| |yc| |θ| |xref| |yref|\n");
    printf("-------------------------------------------------------------------------------------------\n");

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        gerar_referencia(t, &x_ref, &y_ref);
        calcular_controlador(&sistema, x_ref, y_ref);
        gravar_estado(arquivo, t, &sistema, x_ref, y_ref);
        imprimir_terminal(t, &sistema, x_ref, y_ref);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 50000000};
        nanosleep(&req, NULL);
    }

    fclose(arquivo);
    return NULL;
}

// Thread para linearização
void *thread_linearizacao(void *) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        double L[2][2] = {
            {cos(sistema.x[2]), -0.5 * sistema.diametro * sin(sistema.x[2])},
            {sin(sistema.x[2]), 0.5 * sistema.diametro * cos(sistema.x[2])}
        };

        double det = L[0][0] * L[1][1] - L[0][1] * L[1][0];
        double L_inv[2][2] = {
            {L[1][1] / det, -L[0][1] / det},
            {-L[1][0] / det, L[0][0] / det}
        };

        u1 = L_inv[0][0] * sistema.u[0] + L_inv[0][1] * sistema.u[1];
        u2 = L_inv[1][0] * sistema.u[0] + L_inv[1][1] * sistema.u[1];
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 40000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

// Thread para modelos de referência
void *thread_modelos_referencia(void *) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        atualizar_modelo_referencia(y_mx, y_my, sistema.u[0], sistema.u[1]);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 50000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

// Thread para geração de referências
void *thread_gerar_referencia(void *) {
    double t = 0.0;
    struct timespec tp_start, tp_stop;
    clock_gettime(CLOCK_MONOTONIC, &tp_start);

    double x_ref = 0.0, y_ref = 0.0;

    while (t <= SIM_TIME) {
        clock_gettime(CLOCK_MONOTONIC, &tp_stop);
        t = timespec_diff(&tp_start, &tp_stop);

        pthread_mutex_lock(&mutex);
        gerar_referencia(t, &x_ref, &y_ref);
        pthread_mutex_unlock(&mutex);

        struct timespec req = {.tv_sec = 0, .tv_nsec = 120000000};
        nanosleep(&req, NULL);
    }
    return NULL;
}

void gerar_graficos(const char *filename) {
    FILE *gnuplotPipe = popen("gnuplot -persistent", "w");
    if (gnuplotPipe == NULL) {
        fprintf(stderr, "Erro ao abrir o Gnuplot.\n");
        return;
    }

    fprintf(gnuplotPipe, "set title 'Gráfico com múltiplos eixos Y'\n"); // Título
    fprintf(gnuplotPipe, "set xlabel 'Tempo (t) [s]'\n");                // Rótulo do eixo X
    fprintf(gnuplotPipe, "set ylabel 'Valores'\n");                      // Rótulo do eixo Y
    fprintf(gnuplotPipe, "set grid\n");                                  // Grade
    fprintf(gnuplotPipe, "set key outside\n");                           // Legenda fora do gráfico

    //fprintf(gnuplotPipe, "set multiplot layout 2,1 title 'Gráficos Combinados'\n");

    /*fprintf(gnuplotPipe,
            "plot '%s' using 1:4 with lines title '|xc|', "
            "'%s' using 1:5 with lines title '|yc|', "
            "'%s' using 1:6 with lines title '|θ|'\n",
            filename, filename, filename);*/

    fprintf(gnuplotPipe,
            "plot '%s' using 4:5 with lines title 'Trajetória: |xc| x |yc|'\n",
            filename);

    //fprintf(gnuplotPipe, "unset multiplot\n");

    pclose(gnuplotPipe);

    printf("Gráfico gerado com sucesso para o arquivo '%s'.\n", filename);
}

int main() {
    pthread_t th_ref, th_modelo_ref, th_controle, th_linearizacao, th_simulacao;
    const char *arquivo = "saida.txt";
    double *tempos = NULL, *t_values = NULL, *j_values = NULL;
    Estatisticas stats_t, stats_j;
    size_t tamanho;

    // Inicializa o estado do sistema
    inicializar_estado(&sistema);

    // Criação das threads
    pthread_create(&th_simulacao, NULL, thread_simulacao_dinamica, NULL);
    pthread_create(&th_controle, NULL, thread_controle, NULL);
    pthread_create(&th_linearizacao, NULL, thread_linearizacao, NULL);
    pthread_create(&th_modelo_ref, NULL, thread_modelos_referencia, NULL);
    pthread_create(&th_ref, NULL, thread_gerar_referencia, NULL);

    // Espera pelas threads
    pthread_join(th_simulacao, NULL);
    pthread_join(th_controle, NULL);
    pthread_join(th_linearizacao, NULL);
    pthread_join(th_modelo_ref, NULL);
    pthread_join(th_ref, NULL);

    gerar_graficos(arquivo);

    tamanho = ler_dados(arquivo, &tempos, &t_values, &j_values);
    if (tamanho == 0) {
        printf("Erro ao processar os dados.\n");
        return 1;
    }

    stats_t = calcular_estatisticas(t_values, tamanho - 1);
    stats_j = calcular_estatisticas(j_values, tamanho - 1);

    imprimir_tabela(stats_t, stats_j);

    free(tempos);
    free(t_values);
    free(j_values);

    return 0;
}
