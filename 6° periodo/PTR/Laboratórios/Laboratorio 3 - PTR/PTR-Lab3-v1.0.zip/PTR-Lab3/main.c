#include "sistema.h"
#include "io.h"
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

#define SIM_STEP 30  // Período de simulação em ms
#define OUTPUT_STEP 50 // Período de saída em ms
#define SIM_TIME 20.0 // Tempo total de simulação em segundos

Sistema sistema;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

// Thread para simulação
void *thread_simulacao(void *args) {
    double t = 0.0;
    FILE *arquivo = fopen("saida.txt", "w");
    if (!arquivo) {
        perror("Erro ao abrir o arquivo");
        return NULL;
    }

    while (t <= SIM_TIME) {
        pthread_mutex_lock(&mutex);
        atualizar_entrada(&sistema, t);
        atualizar_estado(&sistema, SIM_STEP / 1000.0); // Converte ms para s
        pthread_mutex_unlock(&mutex);
        usleep(SIM_STEP * 1000); // 30ms
        t += SIM_STEP / 1000.0;
    }

    fclose(arquivo);
    return NULL;
}

// Thread para calcular yf e salvar
void *thread_saida(void *args) {
    double t = 0.0;
    FILE *arquivo = fopen("saida.txt", "a");
    if (!arquivo) {
        perror("Erro ao abrir o arquivo");
        return NULL;
    }

    while (t <= SIM_TIME) {
        pthread_mutex_lock(&mutex);
        calcular_saida(&sistema);
        salvar_estado(arquivo, t, &sistema);
        pthread_mutex_unlock(&mutex);
        usleep(OUTPUT_STEP * 1000); // 50ms
        t += OUTPUT_STEP / 1000.0;
    }

    fclose(arquivo);
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    inicializar_sistema(&sistema);

    pthread_create(&thread1, NULL, thread_simulacao, NULL);
    pthread_create(&thread2, NULL, thread_saida, NULL);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    return 0;
}
