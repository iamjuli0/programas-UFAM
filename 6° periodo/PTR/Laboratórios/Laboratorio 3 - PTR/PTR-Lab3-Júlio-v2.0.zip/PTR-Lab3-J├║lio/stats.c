#include "stats.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

// Função para calcular estatísticas
Estatisticas calcular_estatisticas(double *dados, size_t tamanho) {
    Estatisticas stats = {0};
    if (tamanho == 0) return stats;

    double soma = 0.0, soma_quadrados = 0.0;
    stats.maximo = -DBL_MAX;
    stats.minimo = DBL_MAX;

    for (size_t i = 0; i < tamanho; i++) {
        soma += dados[i];
        soma_quadrados += dados[i] * dados[i];
        if (dados[i] > stats.maximo) stats.maximo = dados[i];
        if (dados[i] < stats.minimo) stats.minimo = dados[i];
    }

    stats.media = soma / tamanho;
    stats.variancia = (soma_quadrados / tamanho) - (stats.media * stats.media);
    stats.desvio_padrao = sqrt(stats.variancia);

    return stats;
}

// Função para ler dados do arquivo
size_t ler_dados(const char *filename, double **t_values, double **j_values) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Erro ao abrir o arquivo");
        return 0;
    }

    size_t capacidade = 100, tamanho = 0;
    *t_values = (double *)malloc(capacidade * sizeof(double));
    *j_values = NULL; // Será alocado posteriormente

    char linha[256];
    int ignorar_cabecalho = 1;

    while (fgets(linha, sizeof(linha), file)) {
        if (ignorar_cabecalho) {
            ignorar_cabecalho = 0; // Ignora a primeira linha (cabeçalho)
            continue;
        }

        double t, v, w, xc, yc, theta;
        if (sscanf(linha, "%lf %lf %lf %lf %lf %lf", &t, &v, &w, &xc, &yc, &theta) == 6) {
            if (tamanho == capacidade) {
                capacidade *= 2;
                *t_values = (double *)realloc(*t_values, capacidade * sizeof(double));
            }
            (*t_values)[tamanho++] = t;
        }
    }
    fclose(file);

    // Calcula J(k) = T(k+1) - T(k)
    if (tamanho > 1) {
        *j_values = (double *)malloc((tamanho - 1) * sizeof(double));
        for (size_t i = 0; i < tamanho - 1; i++) {
            (*j_values)[i] = (*t_values)[i + 1] - (*t_values)[i];
        }
    }

    return tamanho;
}

void imprimir_tabela(Estatisticas stats_t, Estatisticas stats_j) {
    printf("\nTabela Comparativa:\n");
    printf("----------------------------------------------------------\n");
    printf("|       | Média   | Variância | Desvio   | Máximo  | Mínimo |\n");
    printf("|       |         |           | Padrão   |         |        |\n");
    printf("----------------------------------------------------------\n");
    printf("| T(k)  | %7.5f | %9.5f | %8.5f | %7.5f | %7.5f |\n",
           stats_t.media, stats_t.variancia, stats_t.desvio_padrao,
           stats_t.maximo, stats_t.minimo);
    printf("| J(k)  | %7.5f | %9.5f | %8.5f | %7.5f | %7.5f |\n",
           stats_j.media, stats_j.variancia, stats_j.desvio_padrao,
           stats_j.maximo, stats_j.minimo);
    printf("----------------------------------------------------------\n");
}

